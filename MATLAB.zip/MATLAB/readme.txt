Here MATLAB and SIMULINK code will be added

.m for matabcode
.slx for simulink code
